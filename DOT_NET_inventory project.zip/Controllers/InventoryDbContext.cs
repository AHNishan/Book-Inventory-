﻿namespace DOT_NET_inventory_project.Controllers
{
    internal class InventoryDbContext
    {
    }
}